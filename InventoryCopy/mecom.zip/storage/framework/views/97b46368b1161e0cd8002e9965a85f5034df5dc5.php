<?php
$banner = App\Models\Banner::orderBy('banner_title','ASC')->limit(3)->get();
?>

<section class="banners mb-25">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-4 col-md-6">
                <div class="banner-img wow animate__animated animate__fadeInUp" data-wow-delay="0">
                    <img src="<?php echo e(asset( $item->banner_image )); ?>" alt="" />
                    <div class="banner-text">
                        <h4>
                            <?php echo e($item->banner_title); ?>

                        </h4>
                        <a href="<?php echo e($item->banner_url); ?>" class="btn btn-xs">Shop Now <i
                                class="fi-rs-arrow-small-right"></i></a>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section><?php /**PATH D:\xampp\htdocs\mecom\resources\views/frontend/home/home_banner.blade.php ENDPATH**/ ?>