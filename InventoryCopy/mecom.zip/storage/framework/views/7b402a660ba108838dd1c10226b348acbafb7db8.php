<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="<?php echo e(asset('adminbackend/assets/images/favicon-32x32.png')); ?>" type="image/png" />

    <link href="<?php echo e(asset('adminbackend/assets/plugins/input-tags/css/tagsinput.css')); ?>" rel="stylesheet" />


    <!--plugins-->
    <link href="<?php echo e(asset('adminbackend/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('adminbackend/assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('adminbackend/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>"
        rel="stylesheet" />
    <link href="<?php echo e(asset('adminbackend/assets/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
    <!-- loader-->
    <link href="<?php echo e(asset('adminbackend/assets/css/pace.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('adminbackend/assets/js/pace.min.js')); ?>"></script>
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('adminbackend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminbackend/assets/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminbackend/assets/css/icons.css')); ?>" rel="stylesheet">
    <!-- Theme Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('adminbackend/assets/css/dark-theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('adminbackend/assets/css/semi-dark.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('adminbackend/assets/css/header-colors.css')); ?>" />

    <!-- DataTable -->
    <link href="<?php echo e(asset('adminbackend/assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>"
        rel="stylesheet" />
    <!-- DataTable-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
        integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    .page-content {
        padding-left: 260px;
        /* Adjust this value based on your sidebar width */
    }
    </style>




    <title>All Notification</title>
</head>

<body>

    <div class="wrapper">
        <?php echo $__env->make('admin.body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">All Notifications</div>
            <div class="ps-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">All Notifications</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!--end breadcrumb-->

        <hr />
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <div class="header-notifications-list">
                            <?php
                            $user = Auth::user();
                            $notifications = $user->notifications->take(10); // Limit to 10 notifications
                            ?>

                            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a class="dropdown-item" href="javascript:;">
                                <div class="d-flex align-items-center">
                                    <div class="notify bg-light-warning text-warning"><i class="bx bx-send"></i></div>
                                    <div class="flex-grow-1">
                                        <h6 class="msg-name">Message <span
                                                class="msg-time float-end"><?php echo e(Carbon\Carbon::parse($notification->created_at)->diffForHumans()); ?>

                                            </span></h6>
                                        <p class="msg-info"><?php echo e($notification->data['message']); ?></p>
                                    </div>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <!-- Handle empty notifications -->
                            <?php endif; ?>
                        </div>
                    </table>
                </div>
            </div>
        </div>

        <!-- Clear All Button -->
        <form action="<?php echo e(route('clear.notification')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Clear All Notifications</button>
        </form>

    </div>





    <script src="<?php echo e(asset('adminbackend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <!--plugins-->
    <script src="<?php echo e(asset('adminbackend/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/chartjs/js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/sparkline-charts/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/jquery-knob/excanvas.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/plugins/jquery-knob/jquery.knob.js')); ?>"></script>
    <script>
    $(function() {
        $(".knob").knob();
    });
    </script>
    <script src="<?php echo e(asset('adminbackend/assets/js/index.js')); ?>"></script>
    <script src="<?php echo e(asset('adminbackend/assets/js/validate.min.js')); ?>"></script>

    <!--Datatable-->
    <script src="<?php echo e(asset('adminbackend/assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
    <script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
    </script>
    <!--Datatable-->

    <!--app JS-->
    <script src="<?php echo e(asset('adminbackend/assets/js/app.js')); ?>"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


    <script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"
    switch (type) {
        case 'info':
            toastr.info(" <?php echo e(Session::get('message')); ?> ");
            break;

        case 'success':
            toastr.success(" <?php echo e(Session::get('message')); ?> ");
            break;

        case 'warning':
            toastr.warning(" <?php echo e(Session::get('message')); ?> ");
            break;

        case 'error':
            toastr.error(" <?php echo e(Session::get('message')); ?> ");
            break;
    }
    <?php endif; ?>
    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="<?php echo e(asset('adminbackend/assets/js/code.js')); ?>"></script>

    <script src="<?php echo e(asset('adminbackend/assets/plugins/input-tags/js/tagsinput.js')); ?>"></script>

    <script src='https://cdn.tiny.cloud/1/vdqx2klew412up5bcbpwivg1th6nrh3murc6maz8bukgos4v/tinymce/5/tinymce.min.js'
        referrerpolicy="origin">
    </script>

    <script>
    tinymce.init({
        selector: '#mytextarea'
    });
    </script>

</body>

</html><?php /**PATH D:\xampp\htdocs\mecom\resources\views/backend/notification/notification.blade.php ENDPATH**/ ?>