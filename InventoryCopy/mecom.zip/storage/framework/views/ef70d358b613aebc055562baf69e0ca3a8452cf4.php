<?php $__env->startSection('main'); ?>

<?php $__env->startSection('title'); ?>
Cash Payment
<?php $__env->stopSection(); ?>

<div class="page-header breadcrumb-wrap">
    <div class="container">
        <div class="breadcrumb">
            <a href="index.html" rel="nofollow"><i class="fi-rs-home mr-5"></i>Home</a>
            <span></span> Cash On Delivery
        </div>
    </div>
</div>
<div class="container mb-80 mt-50">
    <div class="row">
        <div class="col-lg-8 mb-40">
            <h3 class="heading-2 mb-10">Cash On Delivery Payment</h3>
            <div class="d-flex justify-content-between">

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">


            <div class="border p-40 cart-totals ml-30 mb-50">
                <div class="d-flex align-items-end justify-content-between mb-30">
                    <h4>Your Order Details</h4>

                </div>
                <div class="divider-2 mb-30"></div>
                <div class="table-responsive order_table checkout">

                    <table class="table no-border">
                        <tbody>

                            <?php if(Session::has('coupon')): ?>

                            <tr>
                                <td class="cart_total_label">
                                    <h6 class="text-muted">Subtotal</h6>
                                </td>
                                <td class="cart_total_amount">
                                    <h4 class="text-brand text-end">$<?php echo e($cartTotal); ?></h4>
                                </td>
                            </tr>

                            <tr>
                                <td class="cart_total_label">
                                    <h6 class="text-muted">Coupn Name</h6>
                                </td>
                                <td class="cart_total_amount">
                                    <h6 class="text-brand text-end"><?php echo e(session()->get('coupon')['coupon_name']); ?> (
                                        <?php echo e(session()->get('coupon')['coupon_discount']); ?>% )</h6>
                                </td>
                            </tr>

                            <tr>
                                <td class="cart_total_label">
                                    <h6 class="text-muted">Coupon Discount</h6>
                                </td>
                                <td class="cart_total_amount">
                                    <h4 class="text-brand text-end">$<?php echo e(session()->get('coupon')['discount_amount']); ?>

                                    </h4>
                                </td>
                            </tr>

                            <tr>
                                <td class="cart_total_label">
                                    <h6 class="text-muted">Grand Total</h6>
                                </td>
                                <td class="cart_total_amount">
                                    <h4 class="text-brand text-end">$<?php echo e(session()->get('coupon')['total_amount']); ?></h4>
                                </td>
                            </tr>

                            <?php else: ?>



                            <tr>
                                <td class="cart_total_label">
                                    <h6 class="text-muted">Grand Total</h6>
                                </td>
                                <td class="cart_total_amount">
                                    <h4 class="text-brand text-end">$<?php echo e($cartTotal); ?></h4>
                                </td>
                            </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>





                </div>
            </div>


        </div> <!-- // end lg md 6 -->


        <div class="col-lg-6">
            <div class="border p-40 cart-totals ml-30 mb-50">
                <div class="d-flex align-items-end justify-content-between mb-30">
                    <h4>Make Cash Payment </h4>

                </div>
                <div class="divider-2 mb-30"></div>
                <div class="table-responsive order_table checkout">


                    <form action="<?php echo e(route('cash.order')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <label for="card-element">


                                <input type="hidden" name="name" value="<?php echo e($data['shipping_name']); ?>">
                                <input type="hidden" name="email" value="<?php echo e($data['shipping_email']); ?>">
                                <input type="hidden" name="phone" value="<?php echo e($data['shipping_phone']); ?>">
                                <input type="hidden" name="post_code" value="<?php echo e($data['post_code']); ?>">
                                <input type="hidden" name="division_id" value="<?php echo e($data['division_id']); ?>">
                                <input type="hidden" name="district_id" value="<?php echo e($data['district_id']); ?>">
                                <input type="hidden" name="state_id" value="<?php echo e($data['state_id']); ?>">
                                <input type="hidden" name="address" value="<?php echo e($data['shipping_address']); ?>">
                                <input type="hidden" name="notes" value="<?php echo e($data['notes']); ?>">


                            </label>

                            <!-- Used to display form errors. -->

                        </div>
                        <br>
                        <button class="btn btn-primary">Submit Payment</button>
                    </form>


                </div>
            </div>



        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mecom\resources\views/frontend/payment/cash.blade.php ENDPATH**/ ?>